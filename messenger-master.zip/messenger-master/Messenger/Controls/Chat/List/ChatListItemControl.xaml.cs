﻿using System.Windows.Controls;

namespace Messenger
{
    /// <summary>
    /// Interaction logic for ChatListItemControl.xaml
    /// </summary>
    public partial class ChatListItemControl : UserControl
    {
        public ChatListItemControl()
        {
            InitializeComponent();
        }
    }
}
