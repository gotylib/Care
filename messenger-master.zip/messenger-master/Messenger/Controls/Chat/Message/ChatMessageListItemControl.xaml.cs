﻿using System.Windows.Controls;

namespace Messenger
{
    /// <summary>
    /// Interaction logic for ChatMessageListItemControl.xaml
    /// </summary>
    public partial class ChatMessageListItemControl : UserControl
    {
        public ChatMessageListItemControl()
        {
            InitializeComponent();
        }
    }
}
